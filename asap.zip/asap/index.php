<?php
/*
	Template Name: Home Page
*/

get_header(); ?>

	<?php get_template_part('content','mainslider'); ?>

	<?php get_template_part('content','whatwedo'); ?>

	<?php get_template_part('content','ourusers'); ?>

	<?php get_template_part('content','whatweserve'); ?>

	<?php get_template_part('content','industries'); ?>

<?php get_footer(); ?>