<section id="main-slider">
	<div class="container-fluid" style="padding-left:0;padding-right:0">
		<div class='slider'>
			<div class='slide1'>
				<p class="slider-title">Inventory System,<br />
				Asset Tracking<br />
				& All-In-One<br />
				Solutions.</p>

				<p class="slider-desc">
					An Inventory System and Asset <br/>
					Tracking Solutions, configurable <br />
					for Every Business.<br />
				</p>

				<a href="#" class="square_btn">Get Started Now for Free</a>
			</div>
			<div class='slide2'>

				<p class="slider-title">Inventory System,<br />
					Asset Tracking<br />
					& All-In-One<br />
					Solutions.</p>

				<p class="slider-desc">
					An Inventory System and Asset <br />
					Tracking Solutions, configurable <br />
					for Every Business.<br />
				</p>

				<a href="#" class="square_btn">Get Started Now for Free</a>


			</div>
			<div class='slide3'>

				<p class="slider-title">Inventory System,<br />
					Asset Tracking<br />
					& All-In-One<br />
					Solutions.</p>

				<p class="slider-desc">
					An Inventory System and Asset <br />
					Tracking Solutions, configurable <br />
					for Every Business.<br />
				</p>

				<a href="#" class="square_btn">Get Started Now for Free</a>


			</div>
		</div>
	</div>
</section>