$(function () {
  var lineBar3 = new ProgressBar.Line(".line3", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar4 = new ProgressBar.Line(".line4", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar5 = new ProgressBar.Line(".line5", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar6 = new ProgressBar.Line(".line6", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar7 = new ProgressBar.Line(".line7", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar8 = new ProgressBar.Line(".line8", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar9 = new ProgressBar.Line(".line9", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar10 = new ProgressBar.Line(".line10", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });
  var lineBar11 = new ProgressBar.Line(".line11", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar12 = new ProgressBar.Line(".line12", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });
  var lineBar13 = new ProgressBar.Line(".line13", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar14 = new ProgressBar.Line(".line14", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });
  var lineBar15 = new ProgressBar.Line(".line15", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });

  var lineBar16 = new ProgressBar.Line(".line16", {
    strokeWidth: 2,
    easing: "easeInOut",
    duration: 1400,
    color: "#FFEA82",
    trailColor: "#eee",
    trailWidth: 2,
    svgStyle: { width: "100%", height: "100%" },
    from: { color: "#3f95d3" },
    to: { color: "#67bb85" },
    step: (state, bar) => {
      bar.path.setAttribute("stroke", state.color);
    },
  });
  // Reference the tab links.
  const tabLinks = $("#tab-links li a");

  // Generate accordion headings for each section.
  tabLinks.each(function (index) {
    var $this = $(this);

    // If this is the first item, add the active class.
    if (index == 0) {
      $this.addClass("active");
    }

    $($this.attr("href")).before($this.clone().addClass("accordion-heading"));
  });

  // Handle link clicks.
  $("[data-tab-nav]").click(function (event) {
    var $this = $(this),
      target = $this.attr("href");

    // Prevent default click behaviour.
    event.preventDefault();

    // Remove the active class from the active link and section.
    $(
      "#tab-links a.active, section.active, .accordion-heading.active"
    ).removeClass("active");

    // Add the active class to the current link, corresponding section and accordion heading.
    $(target).addClass("active");
    $('a[href^="' + target + '"]').addClass("active");

    lineBar3.animate(0.4, {
      duration: 1000,
    });

    lineBar4.animate(0.8, {
      duration: 1000,
    });

    lineBar5.animate(0.2, {
      duration: 1000,
    });

    lineBar6.animate(0.3, {
      duration: 1000,
    });

    lineBar7.animate(0.5, {
      duration: 1000,
    });

    lineBar8.animate(0.6, {
      duration: 1000,
    });

    lineBar9.animate(0.6, {
      duration: 1000,
    });

    lineBar10.animate(0.9, {
      duration: 1000,
    });

    lineBar11.animate(0.3, {
      duration: 1000,
    });

    lineBar12.animate(0.7, {
      duration: 1000,
    });
    lineBar13.animate(0.5, {
      duration: 1000,
    });

    lineBar14.animate(0.2, {
      duration: 1000,
    });

    lineBar15.animate(1, {
      duration: 1000,
    });

    lineBar16.animate(0.1, {
      duration: 1000,
    });

    $(".count").each(function () {
      $(this)
        .prop("Counter", 0)
        .animate(
          {
            Counter: $(this).text(),
          },
          {
            duration: 4000,
            easing: "swing",
            step: function (now) {
              $(this).text(Math.ceil(now));
            },
          }
        );
    });
  });
});
